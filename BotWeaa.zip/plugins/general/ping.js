let handler = async (m, { conn }) => {
    const start = Date.now(); // Waktu awal saat command diterima
    
    // Hitung waktu yang dibutuhkan dari awal hingga sebelum kirim balasan
    const latency = Date.now() - start;

    // Kirim hasil ping dalam ms
    await m.reply(`*Ping*: ${latency} ms`);
};

handler.help = ['ping'];
handler.tags = ['general'];
handler.command = ['ping', 'speed'];

module.exports = handler;