const moment = require('moment-timezone');
const os = require('os');

let tags = {};

const defaultMenu = {
    before: `
Hai @%name 🔥
%readmore
`.trimStart(),
    header: '*乂 %category*',
    body: '• %cmd %isPremium',
    footer: '\n',
    after: "By Denji",
}

let handler = async (m, { conn, usedPrefix: _p }) => {
    try {
        let names = await conn.getName(m.sender);
        let now = moment().tz('Asia/Jakarta'); // Waktu saat ini dengan zona WIB
        let wib = now.format("dddd, DD MMMM YYYY HH:mm:ss [WIB]");
        let wita = now.tz('Asia/Makassar').format("dddd, DD MMMM YYYY HH:mm:ss [WITA]");
        let wit = now.tz('Asia/Jayapura').format("dddd, DD MMMM YYYY HH:mm:ss [WIT]");
        let uptime = clockString(process.uptime() * 1000);
        let totalreg = Object.keys(global.db.data.users).length;
        let help = Object.values(global.plugins).filter(plugins => !plugins.disabled).map(plugins => ({
            help: Array.isArray(plugins.tags) ? plugins.help : [plugins.help],
            tags: Array.isArray(plugins.tags) ? plugins.tags : [plugins.tags],
            prefix: 'customPrefix' in plugins,
            premium: plugins.premium,
            enabled: !plugins.disabled,
        }));

        // Menambahkan kategori yang ada ke dalam objek tags
        for (let plugins of help) {
            for (let tag of plugins.tags) {
                if (tag && !(tag in tags)) tags[tag] = tag;
            }
        }

        let before = conn.menu?.before || defaultMenu.before;
        let header = conn.menu?.header || defaultMenu.header;
        let body = conn.menu?.body || defaultMenu.body;
        let footer = conn.menu?.footer || defaultMenu.footer;
        let after = conn.menu?.after || defaultMenu.after;

        let menuText = [
            before,
            ...Object.keys(tags)
                .sort((a, b) => tags[a].localeCompare(tags[b])) // Mengurutkan kategori dari A ke Z
                .map(tag => {
                    let commandsInCategory = help.filter(menu => menu.tags.includes(tag));
                    if (commandsInCategory.length === 0) return ''; // Skip kategori yang tidak memiliki perintah

                    return header.replace(/%category/g, tags[tag]) + '\n' + [
                        ...commandsInCategory.map(menu => 
                            menu.help.map(help => 
                                body.replace(/%cmd/g, menu.prefix ? help : '%p' + help)
                                    .replace(/%isPremium/g, menu.premium ? '🅟' : '')
                                    .trim()
                            ).join('\n')
                        ),
                        footer
                    ].join('\n')
                }).filter(category => category !== ''), // Hapus kategori yang kosong
            after
        ].join('\n');

        let replace = {
            '%': '%', p: _p, uptime,
            me: conn.getName(conn.user.jid),
            name: m.sender.split('@')[0], names,
            wib, wita, wit, totalreg, readmore: readMore
        };

        menuText = menuText.replace(new RegExp(`%(${Object.keys(replace).join('|')})`, 'g'), (_, name) => '' + replace[name]);

        // Mengirim menu tanpa mention
        m.reply(menuText, false, { mentions: [m.sender] }); 
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan: ' + error.message);
    }
}

handler.help = ['menu'];
handler.tags = ['general'];
handler.command = ['menu', 'allmenu'];

module.exports = handler;

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}