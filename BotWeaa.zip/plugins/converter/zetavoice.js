const WebSocket = require("ws");
const fs = require("fs");

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || q.mediaType || "";

  if (/audio|video/.test(mime)) {
    let media = await q.download?.();
    m.reply("Tunggu sebentar, sedang diproses...");

    const wss = "wss://yanzbotz-waifu-yanzbotz.hf.space/queue/join";

    function generateRandomLetters(length = 6) {
      const alphabet = "abcdefghijklmnopqrstuvwxyz";
      let result = "";
      for (let i = 0; i < length; i++) {
        result += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
      }
      return result;
    }

    const zeta = async (audio) => {
      return new Promise((resolve, reject) => {
        const name =
          Math.floor(Math.random() * 1e18) + generateRandomLetters() + ".mp4";

        const result = {};
        const sendHasPayload = {
          fn_index: 0,
          session_hash: "xyuk2cf684b",
        };

        const sendDataPayload = {
          fn_index: 0,
          data: [
            {
              data: "data:audio/mpeg;base64," + audio.toString("base64"),
              name: name,
            },
            10,
            "pm",
            0.6,
            false,
            "",
            "en-US-AnaNeural-Female",
          ],
          event_data: null,
          session_hash: "xyuk2cf684b",
        };

        const ws = new WebSocket(wss);

        ws.onopen = () => {
          console.log("Connected to WebSocket");
        };

        ws.onmessage = (event) => {
          const message = JSON.parse(event.data);

          switch (message.msg) {
            case "send_hash":
              ws.send(JSON.stringify(sendHasPayload));
              break;

            case "send_data":
              console.log("Processing your audio...");
              ws.send(JSON.stringify(sendDataPayload));
              break;

            case "process_completed":
              result.base64 =
                "https://yanzbotz-waifu-yanzbotz.hf.space/file=" +
                message.output.data[1].name;
              break;
          }
        };

        ws.onclose = (event) => {
          if (event.code === 1000) {
            console.log("Process completed");
          } else {
            m.reply("Error: WebSocket Connection Error.");
          }
          resolve(result);
        };

        ws.onerror = (error) => {
          reject("WebSocket Error: " + error.message);
        };
      });
    };

    let res = await zeta(await media);
    if (res?.base64) {
      conn.sendFile(m.chat, res.base64, "", "", m);
    } else {
      m.reply("Gagal memproses audio.");
    }

  } else {
    throw `Balas audio/video dengan caption *${usedPrefix + command}*`;
  }
};

handler.help = ["zetavoice"];
handler.command = ["zetavoice", "voicezeta", "zeta-voice"];
handler.tags = ["converter"];
handler.limit = true;

module.exports = handler;
