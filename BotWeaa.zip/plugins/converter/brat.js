const fetch = require('node-fetch');

let handler = async (m, { conn, text }) => {
   if (!text) return conn.reply(m.chat, `Berikan teks atau masukan teks`, m);
   if (text.length > 50000) return m.reply(`Max 50000 characters.`);

   try {
      const url = `https://aqul-brat.hf.space/api/brat?text=${encodeURIComponent(text)}`;
      const response = await fetch(url);
      
      if (!response.ok) return conn.reply(m.chat, `API request failed with status: ${response.status}`, m);
      
      const processedMedia = await response.buffer();

      // Kirim sebagai sticker gambar dengan packname dan author global
      await conn.sendImageAsSticker(m.chat, processedMedia, m, {
         packname: global.packname,
         author: global.author
      });

   } catch (e) {
      console.error(e);
      return conn.reply(m.chat, `Terjadi kesalahan, coba lagi nanti.`, m);
   }
};

handler.help = ['brat'];
handler.tags = ['converter'];
handler.command = ["brat", "brt"]
handler.limit = true;

module.exports = handler;
