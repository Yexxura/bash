const axios = require('axios');
const FormData = require('form-data');
const {
    Buffer
} = require('buffer');
const WebSocket = require('ws');
const crypto = require('node:crypto');
const fetch = require('node-fetch');

const WS_URL = 'wss://pixnova.ai/demo-photo2anime/queue/join';
const IMAGE_URL = 'https://oss-global.pixnova.ai/';
const SESSION = crypto.randomBytes(5).toString('hex').slice(0, 9);
let wss;
let promise;

// Uploader ke Uguu
async function Uguu(buffer, filename) {
    const form = new FormData();
    form.append('files[]', buffer, {
        filename
    });

    const {
        data
    } = await axios.post('https://uguu.se/upload.php', form, {
        headers: form.getHeaders(),
    });

    if (!data.files || !data.files[0]) throw 'Upload gagal.';
    return data.files[0].url;
}

// Koneksi WebSocket
function _connect(log) {
    return new Promise((resolve, reject) => {
        wss = new WebSocket(WS_URL);
        wss.on('open', () => {
            if (log) console.log('[ INFO ] Koneksi websocket berhasil.');
            resolve();
        });

        wss.on('error', (err) => {
            console.error('[ ERROR ]', err);
            reject(err);
        });

        wss.on('message', (chunk) => {
            const data = JSON.parse(chunk.toString());
            if (promise && promise.once) {
                promise.call(data);
                promise = null;
            } else if (promise && !promise.once) {
                if (log) console.log(data);
                if (data?.code == 200 && data?.success) {
                    data.output.result = data.output.result.map(x => IMAGE_URL + x);
                    promise.call(data);
                    promise = null;
                }
            }
        });
    });
}

// Kirim Payload ke WebSocket
function _send(payload, pr) {
    return new Promise((resolve) => {
        wss.send(JSON.stringify(payload));
        promise = {
            once: pr,
            call: resolve
        };
    });
}

// Fungsi utama PixNova
async function PixNova(data, image, log) {
    let base64Image;

    if (/^https?:\/\//i.test(image)) {
        const res = await fetch(image);
        const arrBuf = await res.arrayBuffer();
        base64Image = Buffer.from(arrBuf).toString('base64');
    } else if (Buffer.isBuffer(image)) {
        base64Image = image.toString('base64');
    } else {
        base64Image = image;
    }

    await _connect(log);

    let payload = {
        session_hash: SESSION
    };
    const sessionRes = await _send(payload, true);
    if (log) console.log(`[${SESSION}] Hash: ${JSON.stringify(sessionRes, null, 2)}`);

    payload = {
        data: {
            source_image: `data:image/jpeg;base64,${base64Image}`,
            strength: data?.strength || 0.6,
            prompt: data.prompt,
            negative_prompt: data.negative,
            request_from: 2
        }
    };

    const result = await _send(payload, false);
    return result;
}

// Handler Bot
let handler = async (m, {
    conn,
    args
}) => {
    try {
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';

        if (!/^image\/(jpe?g|png)$/i.test(mime)) {
            throw '*[ ⚠️ ] Hanya foto JPG atau PNG yang didukung.*';
        }

        await conn.sendMessage(m.chat, {
            text: '_[⏳] Sedang memproses gambar ke anime, mohon tunggu..._'
        }, {
            quoted: m
        });

        const media = await q.download();
        const ext = mime.split('/')[1];
        const uploaded = await Uguu(media, `animeupload.${ext}`);

        const DATA = {
            prompt: '(masterpiece), best quality',
            negative: '(worst quality, low quality:1.4), (greyscale, monochrome:1.1), cropped, lowres , username, blurry, trademark, watermark, title, multiple view, Reference sheet, curvy, plump, fat, strabismus, clothing cutout, side slit,worst hand, (ugly face:1.2), extra leg, extra arm, bad foot, text, name',
            strength: 0.6
        };

        const result = await PixNova(DATA, uploaded, true);
        const image = result.output.result[0];

        await conn.sendMessage(m.chat, {
            image: {
                url: image
            },
            caption: ``
        }, {
            quoted: m
        });

    } catch (err) {
        await conn.sendMessage(m.chat, {
            text: `[ Gagal ] ${err}`
        }, {
            quoted: m
        });
    }
};

handler.help = ['jadianime', 'toanime'].map(cmd => `${cmd} [foto]`);
handler.tags = ['converter'];
handler.command = ['jadianime', 'toanime'];
handler.limit = true;

module.exports = handler;