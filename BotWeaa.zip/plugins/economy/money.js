let handler = async (m, { conn }) => {
  let who;

  if (m.isGroup) {
    who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
  } else {
    who = m.sender;
  }

  let user = global.db.data.users[who];
  let response;

  if (user) {
    response = `
*Dompet kamu*

*${user.cents}* Cents 
*${user.limit}* Limit 
*$${user.dollar}* Dollar
    `;
  } else {
    response = `User tidak ditemukan.`;
  }
  
  await m.reply(response.trim());
};

handler.help = ["money"];
handler.tags = ["minigame"];
handler.command = ["money", "pocket", "dompet", "bal"];

module.exports = handler;