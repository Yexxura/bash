const centsPerLimit = 30; // Harga 1 limit = 30 cents

let handler = async (m, { conn, command, args }) => {
  let count;

  if (command) {
    count = command.replace(/^buylimit/i, "");
  }

  if (count) {
    if (/all/i.test(count)) {
      count = Math.floor(global.db.data.users[m.sender].cents / centsPerLimit);
    } else {
      count = parseInt(count) || parseInt(args[0]) || 1;
    }
  } else {
    count = 1;
  }

  count = Math.max(1, count);

  const user = global.db.data.users[m.sender];

  if (user.cents >= centsPerLimit * count) {
    user.cents -= centsPerLimit * count;
    user.limit += count;

    conn.reply(
      m.chat,
      `Berhasil membeli ${count} Limit.\n-${centsPerLimit * count} Cents\n+${count} Limit\n\nLimit kamu sekarang: *${user.limit}*`,
      m
    );
  } else {
    conn.reply(
      m.chat,
      `Cents kamu tidak cukup untuk membeli ${count} Limit.\nKamu butuh ${centsPerLimit * count} Cents, tapi kamu hanya punya ${user.cents}.`,
      m
    );
  }
};

handler.help = ["buylimit", "buylimitall"];
handler.tags = ["economy"];
handler.command = ["buylimit", "buylimitall"];

module.exports = handler;
