let handler = async (m, { conn, args }) => {
  const type = (args[0] || 'dollar').toLowerCase();
  const labelMap = {
    money: 'dollar',
    dollars: 'dollar',
    dollar: 'dollar',
    cents: 'cents',
    limit: 'limit'
  };

  const key = labelMap[type];
  if (!key) return m.reply("Format salah!\nContoh:\n.top\n.top cents\n.top limit");

  let users = Object.entries(global.db.data.users)
    .filter(([_, v]) => typeof v[key] === 'number')
    .sort((a, b) => b[1][key] - a[1][key])
    .slice(0, 10);

  if (!users.length) return m.reply("Belum ada data leaderboard.");

  let text = `*🏆 Leaderboard Teratas (${key.toUpperCase()}):*\n\n` +
    (await Promise.all(users.map(async ([jid, data], i) => {
      let name;
      try {
        name = await conn.getName(jid);
      } catch (e) {
        name = "Pengguna";
      }
      return `${i + 1}. ${name} - ${key === 'dollar' ? '$' : ''}${data[key]}`;
    }))).join("\n");

  await m.reply(text);
};

handler.help = ["top [cents|limit]", "leaderboard [cents|limit]"];
handler.tags = ["minigame"];
handler.command = ["lb", "leaderboard", "top", "topmoney", "topdollar"]; // tambah koma di topmoney & topdollar

module.exports = handler;
