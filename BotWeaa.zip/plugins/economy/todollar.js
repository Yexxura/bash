let handler = async (m, { conn }) => {
  let who = m.isGroup ? (m.mentionedJid[0] || m.sender) : m.sender;
  let user = global.db.data.users[who];

  if (!user) return m.reply("User tidak ditemukan.");

  const centsToDollarRate = 100;
  const earnedDollars = Math.floor(user.cents / centsToDollarRate);
  const remainingCents = user.cents % centsToDollarRate;

  if (earnedDollars > 0) {
    user.dollar += earnedDollars;
    user.cents = remainingCents;
    m.reply(`✅ Berhasil ditukarkan: *${earnedDollars}* Dollar dari *${earnedDollars * 100}* Cents.`);
  } else {
    const neededCents = centsToDollarRate - user.cents;
    m.reply(`Tidak cukup Cents untuk ditukarkan.\nMasih kurang *${neededCents}* Cents lagi untuk mendapatkan 1 Dollar.`);
  }
};

handler.help = ["todollar"];
handler.tags = ["economy"];
handler.command = ["todollar", "tukardollar"];

module.exports = handler;