const fs = require('fs');
const path = require('path');
const { promisify } = require('util');

const readFileAsync = promisify(fs.readFile);
const writeFileAsync = promisify(fs.writeFile);

const bankPath = path.join(__dirname, '../../database/bank.json');

let handler = async (m, { conn, args, usedPrefix }) => {
  const jid = m.sender;

  // Baca atau buat file bank.json jika belum ada
  let bankData = {};
  try {
    const data = await readFileAsync(bankPath, 'utf-8');
    bankData = JSON.parse(data || '{}');
  } catch (e) {
    await writeFileAsync(bankPath, JSON.stringify({}));
  }

  // Validasi user
  if (!global.db.data.users[jid]) return m.reply("Anda belum terdaftar dalam sistem.");
  const user = global.db.data.users[jid];

  const validTypes = ['dollar', 'cents'];
  const subCommand = args[0]?.toLowerCase();

  // Bantuan perintah
  const helpText = `
Penggunaan:
${usedPrefix}bank save <jumlah> <dollar|cents>
${usedPrefix}bank take <jumlah> <dollar|cents>
${usedPrefix}bank check
${usedPrefix}bank cek
`;

  // Cek apakah subCommand valid
  const validCommands = ['save', 'take', 'check', 'cek'];
  if (!subCommand || !validCommands.includes(subCommand)) {
    return m.reply(helpText);
  }

  // Ganti "cek" menjadi "check" agar tidak duplikasi logika
  const actualCommand = subCommand === 'cek' ? 'check' : subCommand;

  if (actualCommand === "check") {
    const balance = bankData[jid] || { dollar: 0, cents: 0 };
    return m.reply(`💰 Saldo di Bank:\n• Dollar: $${balance.dollar || 0}\n• Cents: ${balance.cents || 0}¢`);
  }

  const amount = parseInt(args[1]);
  const type = args[2]?.toLowerCase();

  if (!amount || isNaN(amount) || amount <= 0) return m.reply("Jumlah harus lebih besar dari 0.");
  if (!type || !validTypes.includes(type)) return m.reply("Tipe harus 'dollar' atau 'cents'.");

  const walletAmount = user[type];
  const bankAmount = (bankData[jid] || {})[type] || 0;

  if (actualCommand === "save") {
    if (walletAmount < amount) return m.reply(`Saldo ${type} Anda tidak mencukupi untuk menyimpan sebanyak ini.`);
    
    user[type] -= amount;
    bankData[jid] = bankData[jid] || { dollar: 0, cents: 0 };
    bankData[jid][type] += amount;

    await writeFileAsync(bankPath, JSON.stringify(bankData, null, 2));
    return m.reply(`✅ Berhasil menyimpan *${amount}* ${type} ke dalam bank.`);
  }

  if (actualCommand === "take") {
    if (bankAmount < amount) return m.reply(`Saldo ${type} di bank tidak mencukupi untuk ditarik.`);

    user[type] += amount;
    bankData[jid][type] -= amount;

    if (bankData[jid][type] <= 0) delete bankData[jid][type];
    if (Object.keys(bankData[jid] || {}).length === 0) delete bankData[jid];

    await writeFileAsync(bankPath, JSON.stringify(bankData, null, 2));
    return m.reply(`✅ Berhasil menarik *${amount}* ${type} dari bank.`);
  }
};

handler.help = ["bank check", "bank save", "bank take"];
handler.tags = ["economy"];
handler.command = ["bank"];

module.exports = handler;