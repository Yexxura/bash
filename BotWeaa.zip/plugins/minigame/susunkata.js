const gamesUrl = 'https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/susunkata.json ';
let timeout = 30000; // Waktu hanya 30 detik

let handler = async (m, { conn, command, usedPrefix }) => {
  conn.susunkata = conn.susunkata ? conn.susunkata : {};
  let id = m.chat;

  if (id in conn.susunkata) {
    conn.reply(
      m.chat,
      "You already have a question to answer!",
      conn.susunkata[id][0]
    );
    return;
  }

  // Fetch data dari gamesUrl
  try {
    let data = await fetch(gamesUrl).then((response) => response.json());
    if (!data.result || !Array.isArray(data.result)) {
      throw new Error("Invalid data format from the JSON URL.");
    }

    // Pilih soal secara acak
    let result = data.result[Math.floor(Math.random() * data.result.length)];
    let { soal, jawaban, tipe } = result;

    let caption = `*[ SUSUN KATA ]*
*• Timeout :* 30 seconds
*• Question :* ${soal} 
*• Hint :* ${tipe || 'General'}

Reply to this message to answer the question.
Type *\`nyerah\`* to surrender.`.trim();

    conn.susunkata[id] = [
      await conn.reply(m.chat, caption, m),
      { soal, jawaban },
      setTimeout(() => {
        if (conn.susunkata[id]) {
          conn.sendMessage(
            id,
            {
              text: `Game Over!!
You lose with reason: *[ Timeout ]*

• Answer: *[ ${jawaban} ]*`,
            },
            { quoted: m }
          );
          delete conn.susunkata[id];
        }
      }, timeout),
    ];
  } catch (err) {
    console.error(err);
    conn.reply(m.chat, "An error occurred while fetching the game data.", m);
  }
};

handler.before = async (m, { conn }) => {
  conn.susunkata = conn.susunkata ? conn.susunkata : {};
  let id = m.chat;
  if (!m.text) return;
  if (m.isCommand) return;
  if (!conn.susunkata[id]) return;

  let { soal, jawaban } = conn.susunkata[id][1];
  let reward = db.data.users[m.sender];

  if (m.text.toLowerCase() === "nyerah" || m.text.toLowerCase() === "surrender") {
    clearTimeout(conn.susunkata[id][2]);
    conn.sendMessage(
      m.chat,
      {
        text: `Game Over!!
You lose with reason: *[ ${m.text} ]*

• Answer: *[ ${jawaban} ]*`,
      },
      { quoted: conn.susunkata[id][0] }
    );
    delete conn.susunkata[id];
  } else if (m.text.toLowerCase() === jawaban.toLowerCase()) {
    let rewardCents = 5; // Hanya tambah 1 cent per kemenangan
    reward.cents = (reward.cents || 0) + rewardCents;
    clearTimeout(conn.susunkata[id][2]);

    // Menyertakan mention pemenang
    let winnerMention = `@${m.sender.split("@")[0]}`;
    
    conn.sendMessage(
      m.chat,
      {
        text: `🎉 *Congratulations* ${winnerMention} 🎉
You have successfully guessed the answer!

*Cents:* +${rewardCents}`,
        mentions: [m.sender] // Mention pemenang
      },
      { quoted: conn.susunkata[id][0] }
    );
    delete conn.susunkata[id];
  }
};

handler.help = ["susunkata"];
handler.tags = ["minigame"];
handler.command = ["susunkata"];
handler.group = true;

module.exports = handler;