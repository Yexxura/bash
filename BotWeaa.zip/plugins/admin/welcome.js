let handler = async (
  m,
  { isAdmin, isOwner, isROwner, isBotAdmin, conn, text, args, usedPrefix, command }
) => {
  const chat = global.db.data.chats[m.chat] || {};
  let responseMessage = '';

  //=====================[ FUNGSI SETTING PESAN ]=====================//
  const setMessage = (type, value) => {
    if (isROwner) global.conn[type] = value;
    else if (isOwner) conn[type] = value;
    chat[type] = value;
  };

  //=====================[ HANDLER UNTUK MENGAKTIFKAN/MENONAKTIFKAN WELCOME ]=====================//
  if (command === 'welcome') {
    const isClose = {
      on: true,
      off: false,
    }[args[0]?.toLowerCase()];

    if (isClose === undefined) {
      return m.reply(
        `*[ WELCOME SETTINGS ]*\n\n` +
        `• ${usedPrefix + command} on  → Aktifkan welcome\n` +
        `• ${usedPrefix + command} off → Nonaktifkan welcome`
      );
    }

    chat.welcome = isClose;
    return m.reply(
      isClose
        ? '*[ ✓ ] Fitur welcome berhasil diaktifkan untuk grup ini*'
        : '*[ ✓ ] Fitur welcome berhasil dimatikan untuk grup ini*'
    );
  }

  //=====================[ HANDLER UNTUK SETTING PESAN WELCOME / BYE ]=====================//
  const settingCommand = ['setbye', 'setleft', 'setwelcome', 'setwlc', 'setwelc'];
  if (settingCommand.includes(command)) {
    if (!chat.welcome) {
      return m.reply(
        `⚠️ *Fitur welcome belum aktif!*\n\n` +
        `Aktifkan dulu dengan perintah:\n` +
        `• ${usedPrefix}welcome on`
      );
    }

    if (!text) {
      return m.reply(
        `*⚠️ Silakan masukkan teks yang ingin diatur!*\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*Contoh Penggunaan:*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `• ${usedPrefix}${command} Selamat datang @user di grup @subject!\n` +
        `• ${usedPrefix}${command} Sampai jumpa @user, semoga sukses!\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `*Placeholder yang Didukung:*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `• @user    → Menyebut anggota\n` +
        `• @subject → Nama grup\n` +
        `• @desc    → Deskripsi grup`
      );
    }

    switch (command) {
      case 'setbye':
      case 'setleft':
        setMessage('sBye', text);
        responseMessage =
          `*✅ Pesan perpisahan berhasil disimpan!*\n\n` +
          `Pesan ini akan dikirim saat ada anggota keluar dari grup.\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `*Contoh:*\n\n${text}`;
        break;

      case 'setwelcome':
      case 'setwlc':
      case 'setwelc':
        setMessage('sWelcome', text);
        responseMessage =
          `*✅ Pesan selamat datang berhasil disimpan!*\n\n` +
          `Pesan ini akan dikirim saat ada anggota baru masuk ke grup.\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━\n` +
          `*Contoh:*\n\n${text}`;
        break;
    }

    return m.reply(responseMessage);
  }

  //=====================[ DEFAULT JIKA TIDAK COCOK ]=====================//
  return m.reply(
    `*⚠️ Perintah tidak dikenal!*\n\n` +
    `Gunakan:\n` +
    `• ${usedPrefix}welcome on/off\n` +
    `• ${usedPrefix}setwelcome <teks>\n` +
    `• ${usedPrefix}setbye <teks>`
  );
};

//=====================[ METADATA HANDLER ]=====================//

handler.help = ['welcome [on/off]', 'setwelcome [teks]', 'setbye [teks]'];
handler.tags = ['admin'];
handler.command = ['welcome', 'setwelcome', 'setwlc', 'setwelc', 'setbye', 'setleft'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;
