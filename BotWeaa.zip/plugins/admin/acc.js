let handler = async (m, { conn, args }) => {
  const groupId = m.chat;
  const [subCommand] = args;

  // Format tanggal
  const formatDate = (timestamp) => {
    return new Intl.DateTimeFormat('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(new Date(timestamp * 1000));
  };

  // Fungsi reply
  const reply = (text) => conn.reply(m.chat, text.trim(), m);

  // Ambil daftar permintaan
  const getRequests = async () => {
    try {
      return await conn.groupRequestParticipantsList(groupId);
    } catch (e) {
      reply("Gagal mengambil daftar permintaan.");
      return [];
    }
  };

  // Format daftar permintaan
  const formatList = (list) => {
    if (!list.length) return "Tidak ada permintaan bergabung.";
    return list.map((req, i) => `
*${i + 1}.* 
• Nomor: ${req.jid.split('@')[0]}
• Metode: ${req.request_method}
• Waktu: ${formatDate(req.request_time)}
`).join('\n');
  };

  // Proses approve / reject
  const processAction = async (action, targets, requests) => {
    let result = '';
    let count = 0;

    for (const target of targets) {
      let request = null;

      // Cari berdasarkan nomor urut
      if (!isNaN(target)) {
        request = requests[parseInt(target) - 1];
      } else {
        // Cari berdasarkan JID
        request = requests.find(r => r.jid === target);
      }

      if (!request) continue;

      try {
        const res = await conn.groupRequestParticipantsUpdate(groupId, [request.jid], action);
        const status = res[0].status === 'success' ? 'Berhasil' : 'Gagal';
        result += `• Status: ${status}\n• Nomor: ${request.jid.split('@')[0]}\n\n`;
        count++;
      } catch (e) {
        result += `• Gagal memproses: ${target}\n`;
      }
    }

    if (count === 0 && !result.includes("Gagal")) {
      return "Tidak ada permintaan yang cocok untuk diproses.";
    }

    return `*${action === 'approve' ? 'Menyetujui' : 'Menolak'} Permintaan:*\n\n${result}`;
  };

  switch (subCommand) {
    case "list":
      const requests = await getRequests();
      reply(`*Daftar Permintaan Bergabung:*\n\n${formatList(requests)}`);
      break;

    case "approve":
    case "reject": {
      const options = args.slice(1);
      if (!options.length) {
        reply(`Gunakan: *acc ${subCommand} [nomor|JID|all]*`);
        return;
      }

      const requests = await getRequests();
      const targets = options;

      if (targets.includes("all")) {
        const allJids = requests.map(r => r.jid);
        if (!allJids.length) return reply("Tidak ada permintaan untuk diproses.");

        const res = await conn.groupRequestParticipantsUpdate(groupId, allJids, subCommand);
        const successCount = res.filter(r => r.status === 'success').length;

        reply(`*${subCommand === 'approve' ? 'Disetujui' : 'Ditolak'} semua permintaan*.\nBerhasil: ${successCount}/${res.length}`);
      } else {
        const result = await processAction(subCommand, targets, requests);
        reply(result);
      }
      break;
    }

    default:
      reply(`
Perintah *acc* digunakan untuk mengelola permintaan bergabung ke grup.

Pilihan:
• *acc list* → Melihat daftar permintaan
• *acc approve [nomor|JID|all]* → Menyetujui permintaan
• *acc reject [nomor|JID|all]* → Menolak permintaan

Contoh:
• *acc list*
• *acc approve 1*
• *acc reject user@example.com*
• *acc reject all*
`);
  }
};

handler.help = ['acc'];
handler.tags = ['admin'];
handler.command = ['acc'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;