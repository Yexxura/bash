const fs = require('fs').promises;
const path = require('path');

const DB_BASE_FOLDER = path.join('./database', 'totalpesan');

const getGroupFilePath = (groupId) => {
  const safeGroupId = groupId.replace(/[^a-zA-Z0-9]/g, '_');
  return path.join(DB_BASE_FOLDER, `${safeGroupId}.json`);
};

const fileExists = async (filePath) => {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
};

const loadGroupDatabase = async (groupId) => {
  try {
    const groupFilePath = getGroupFilePath(groupId);
    const exists = await fileExists(groupFilePath);
    if (!exists) {
      throw new Error(`Database untuk grup ini tidak ditemukan.`);
    }

    const data = await fs.readFile(groupFilePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    throw new Error(`Error membaca database: ${error.message}`);
  }
};

const getDayName = (date) => {
  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  return days[date.getDay()];
};

const getFormattedDate = (date) => {
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

const handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');

  const groupId = m.chat;
  const userJid = m.sender;
  const botJid = conn.user.jid;

  try {
    let groupMetadata = await conn.groupMetadata(groupId);
    let participants = groupMetadata.participants.map(p => p.id);

    let groupData = await loadGroupDatabase(groupId);
    let membersData = groupData.members || {};

    let allMembers = {};
    participants.forEach(jid => {
      allMembers[jid] = membersData[jid] || { totalPesan: 0 };
    });

    let sortedMembers = Object.entries(allMembers).sort((a, b) => b[1].totalPesan - a[1].totalPesan);
    let totalMessages = sortedMembers.reduce((acc, [, data]) => acc + data.totalPesan, 0);
    let userMessages = allMembers[userJid]?.totalPesan || 0;
    let userRank = sortedMembers.findIndex(([jid]) => jid === userJid) + 1;

    let pesanList = sortedMembers
      .map(([jid, data], index) => {
        let tag = jid.replace(/(\d+)@.+/, '@$1');
        let total = data.totalPesan;
        return `${index + 1}. ${tag}: ${total} pesan`;
      })
      .join('\n');

    let inactiveCount = sortedMembers.filter(([, data]) => data.totalPesan === 0).length;

    const currentDate = new Date();
    const dayName = getDayName(currentDate);
    const formattedDate = getFormattedDate(currentDate);

    await m.reply(
      `T O T A L   P E S A N\n\n` +
      `Total Pesan: ${totalMessages} dari ${sortedMembers.length} anggota\n` +
      `Tanggal: ${dayName}, ${formattedDate}\n` +
      `Pesan Kamu: ${userMessages} pesan\n` +
      `Peringkat Kamu: #${userRank}\n` +
      `Anggota tanpa pesan: ${inactiveCount}\n\n` +
      `${pesanList}`,
      null,
      {
        contextInfo: {
          mentionedJid: sortedMembers.map(([jid]) => jid),
        },
      }
    );
  } catch (error) {
    return m.reply(`Error: ${error.message}`);
  }
};

handler.help = ['totalpesan'];
handler.tags = ['admin'];
handler.command = ["totalpesan", "listtotalpesan", "bbc", "totalchat"];
handler.group = true;
handler.admin = true

module.exports = handler;