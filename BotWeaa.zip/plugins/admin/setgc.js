let handler = async (m, { conn, args, usedPrefix, command }) => {
    let isClose = { 
        'open': 'not_announcement',
        'close': 'announcement',
        'buka': 'not_announcement',
        'tutup': 'announcement',
    }[(args[0] || '').toLowerCase()] // Mendukung case-insensitive

    if (isClose === undefined) {
        throw `
*Contoh penggunaan fitur:*
  *○ ${usedPrefix + command} tutup*
  *○ ${usedPrefix + command} buka*
`.trim()
    }

    await conn.groupSettingUpdate(m.chat, isClose)
}

handler.help = ['group *[buka/tutup]*']
handler.tags = ['admin']
handler.command = ["group", "grub", "grup"]
handler.admin = true
handler.botAdmin = true

module.exports = handler
