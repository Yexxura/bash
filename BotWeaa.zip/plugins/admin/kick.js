let handler = async (m, { teks, conn, isOwner, isAdmin, args }) => {
    if (m.isBaileys) return;
    if (!(isAdmin || isOwner)) {
        global.dfail('admin', m, conn);
        throw false;
    }

    let ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";

    if (m.quoted) {
        if (m.quoted.sender === ownerGroup || m.quoted.sender === conn.user.jid) {
            return m.reply("Tidak bisa mengeluarkan pemilik grup atau bot.");
        }
        let usr = m.quoted.sender;
        await conn.groupParticipantsUpdate(m.chat, [usr], "remove");
        return m.reply(`@${usr.split('@')[0]} telah dikeluarkan.`, m.chat, { mentions: [usr] });
    }

    if (!m.mentionedJid[0]) {
        return m.reply("Tag pengguna yang ingin dikick.");
    }

    let users = m.mentionedJid.filter(u => !(u == ownerGroup || u.includes(conn.user.jid)));

    if (users.length === 0) {
        return m.reply("Tidak ada pengguna yang valid untuk dikeluarkan.");
    }

    for (let user of users) {
        if (user.endsWith("@s.whatsapp.net")) {
            await conn.groupParticipantsUpdate(m.chat, [user], "remove");
            m.reply(`@${user.split('@')[0]} telah dikeluarkan.`, m.chat, { mentions: [user] });
        }
    }
};

handler.help = ['kick @user'];
handler.tags = ['admin'];
handler.command = ["kick", "keluarkan", "kicks"];
handler.group = true;
handler.botAdmin = true;

module.exports = handler;