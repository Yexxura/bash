const ffmpeg = require("fluent-ffmpeg");

/**
 * Handler untuk mendownload konten TikTok berdasarkan URL.
 */
var handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) {
        throw `*[❗] Contoh penggunaan: ${usedPrefix + command} <URL>*`;
    }

    try {
        await m.reply("*(Downloading...)*");

        const tiktokData = await tiktokdl(args[0]);
        let lastMessage;

        if (!tiktokData || !tiktokData.data) {
            throw "Gagal mendownload video!";
        }

        const videoURL = tiktokData.data.play;
        const images = tiktokData.data.images || [];
        const audioURL = tiktokData.data.music;

        // Info metadata
        const infoText = `
┌──────────────⭓「 *TikTok Downloader* 」
│ 🆔 ID         : ${tiktokData.data.id}
│ 👁️ Views      : ${tiktokData.data.play_count}
│ ❤️ Likes       : ${tiktokData.data.digg_count}
│ 💬 Comments   : ${tiktokData.data.comment_count}
│ 🧑 Author     : ${tiktokData.data.author.nickname}
└───────────────
📝 Title        : ${tiktokData.data.title}
        `.trim();

        // Jika ada gambar (slide)
        if (images.length > 0) {
            for (let image of images) {
                lastMessage = await conn.sendFile(m.chat, image, "image.jpg", infoText, m);
            }

            if (audioURL) {
                await conn.sendMessage(m.chat, {
                    audio: { url: audioURL },
                    mimetype: "audio/mpeg"
                }, { quoted: lastMessage });
            }

        // Jika ada video
        } else if (videoURL) {
            lastMessage = await conn.sendFile(m.chat, videoURL, "tiktok.mp4", infoText, m);

            if (audioURL) {
                await conn.sendMessage(m.chat, {
                    audio: { url: audioURL },
                    mimetype: "audio/mpeg"
                }, { quoted: lastMessage });
            }

            const audioFileName = "lagutt.mp3";
            await convertVideoToMp3(videoURL, audioFileName);

        } else {
            throw "Tidak ada tautan slide/video yang tersedia.";
        }

    } catch (e) {
        await m.reply(`Error: ${e}`);
    }
};

/**
 * Fungsi mengubah video menjadi audio MP3 menggunakan fluent-ffmpeg
 * @param {string} videoUrl - URL video
 * @param {string} outputFileName - Nama file output MP3
 */
async function convertVideoToMp3(videoUrl, outputFileName) {
    return new Promise((resolve, reject) => {
        ffmpeg(videoUrl)
            .toFormat("mp3")
            .on("end", () => resolve())
            .on("error", (err) => reject(err))
            .save(outputFileName);
    });
}

/**
 * Fungsi memanggil API TikWM untuk download data TikTok
 * @param {string} url - URL TikTok
 * @returns {Promise<object>} JSON response dari API
 */
async function tiktokdl(url) {
    const apiUrl = `https://www.tikwm.com/api/?url= ${encodeURIComponent(url)}&hd=1`;
    const response = await fetch(apiUrl);
    return await response.json();
}

// Metadata handler
handler.help = ["tiktok"].map(v => v + " <url>");
handler.tags = ["downloader"];
handler.command = ["tiktokdl", "ttdl", "tt", "dltiktok", "downlaodtiktok", "tiktokslide", "tiktokfoto", "tiktok"];

module.exports = handler;