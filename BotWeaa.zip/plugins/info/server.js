const os = require('os');
let handler = async (m, { conn }) => {
  try {
    // Tambahkan parameter untuk mencegah caching
    const url = 'http://ip-api.com/json?_=' + new Date().getTime(); // Cache buster
    const json = await Func.fetchJson(url);

    // Sensor IP Address
    if (json.query) {
      json.query = json.query.replace(/\d+\.\d+$/, '***.***'); // Sensor dua segmen terakhir
    }

    delete json.status;
    
    let caption = `–  *S E R V E R*\n\n`;
    caption += `┌  ◦  OS : ${os.type()} (${os.arch()} / ${os.release()})\n`;
    caption += `│  ◦  Ram : ${Func.formatSize(process.memoryUsage().rss)} / ${Func.formatSize(os.totalmem())}\n`;

    for (let key in json) {
      caption += `│  ◦  ${Func.ucword(key)} : ${json[key]}\n`;
    }

    caption += `│  ◦  Uptime : ${Func.toTime(os.uptime * 1000)}\n`;
    caption += `└  ◦  Processor : ${os.cpus()[0].model}\n\n`;
    caption += "";

    m.reply(caption);
  } catch (e) {
    return m.reply(String(e));
  }
};

handler.help = ['server *[get bot server info]*'];
handler.tags = ['info'];
handler.command = ["server"];
handler.limit = true;

module.exports = handler;