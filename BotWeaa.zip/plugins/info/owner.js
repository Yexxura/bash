var handler = async (m, { conn }) => {
  const ownerNumber = global.owner;
  const ownerName = global.nameowner;

  const vcard = [
    "BEGIN:VCARD",
    "VERSION:3.0",
    `FN:${ownerName}`,
    `TEL;waid=${ownerNumber}:${ownerNumber}`,
    "END:VCARD"
  ].join("\n");

  const sentMsg = await conn.sendMessage(m.chat, {
    contacts: {
      displayName: ownerName,
      contacts: [{ vcard }]
    }
  }, { quoted: m });

  await conn.reply(m.chat, "*This is my owner's contact number*", sentMsg);
};

handler.help    = ['owner'];
handler.tags    = ['info'];
handler.command = ['owner', 'creator'];
handler.limit   = true;

module.exports = handler;