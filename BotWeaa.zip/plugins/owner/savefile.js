const fs = require("fs");
const path = require("path");

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) {
    throw `*• Usage:* ${usedPrefix + command} [filename]*\n\n` +
          `Contoh:\n` +
          `• ${usedPrefix + command} menu\n` +
          `• ${usedPrefix + command} group/setting`;
  }

  // Cegah akses path berbahaya
  if (text.includes("..")) throw "*[ SECURITY WARNING ]* Path tidak valid.";

  // Bersihkan dan format path
  const filename = text
    .split("/")
    .map(part => part.replace(/[^a-zA-Z0-9_\-]/g, ""))
    .filter(Boolean)
    .join("/");

  const filePath = path.join("plugins", `${filename}.js`);
  const timestamp = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

  switch (command) {
    case "sf":
      if (!m.quoted) throw `*[ ! ] Balas pesan yang berisi kode yang ingin disimpan.*`;
      fs.mkdirSync(path.dirname(filePath), { recursive: true });
      fs.writeFileSync(filePath, m.quoted.text);
      return m.reply(formatMessage("saved", filename, filePath, timestamp));

    case "df":
      if (!fs.existsSync(filePath)) {
        return m.reply(`*[ FILE NOT FOUND ]*\n\n• *File:* ${filename}.js`);
      }
      fs.unlinkSync(filePath);
      return m.reply(formatMessage("deleted", filename, filePath, timestamp));
  }
};

function formatMessage(action, filename, filePath, time) {
  return `*[ FILE ${action.toUpperCase()} SUCCESSFULLY ]*\n\n` +
         `• *Filename:* ${filename}.js\n` +
         `• *Location:* ${filePath}\n` +
         `• *Time:* ${time}`;
}

handler.help = ["sf", "df"].map(cmd => `${cmd} *[reply code / filename]*`);
handler.tags = ["owner"];
handler.command = ["sf", "df"];
handler.rowner = true;

module.exports = handler;
