const handler = async (m, { conn, text }) => {
    let getGroups = await conn.groupFetchAllParticipating();
    let groups = Object.entries(getGroups).map(entry => entry[1]);
    let groupIds = groups.map(v => v.id);

    let pesan = text ? text : m.quoted ? m.quoted.text : '';
    if (!pesan) throw 'Masukkan teks untuk broadcast!';

    m.reply(`Mengirim Broadcast ke ${groupIds.length} grup. Estimasi selesai dalam ${groupIds.length * 30} detik.`);

    let index = 0;

    const sendBroadcast = async () => {
        if (index >= groupIds.length) {
            m.reply(`Sukses mengirim broadcast ke ${groupIds.length} grup!`);
            return;
        }

        await conn.sendMessage(groupIds[index], {
            text: `📣 [ ʙ ʀ ᴏ ᴀ ᴅ ᴄ ᴀ s ᴛ ] 📣\n\n${pesan}`
        });

        index++;
        setTimeout(sendBroadcast, 30000); // Delay 30 detik antar grup
    };

    sendBroadcast();
};

handler.help = ['bcgc'];
handler.tags = ['owner'];
handler.command = ["bcgc", "broadcastgc"];
handler.owner = true;

module.exports = handler;
