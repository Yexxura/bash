const fs = require('fs');

const CONFIG = {
    prefixes: ["bot", "yxuraa"],
    responseMessage: "Apa!",
};

const handler = async (m, { conn }) => {
    const text = (m.text || "").trim().toLowerCase();
    if (!CONFIG.prefixes.includes(text)) return;

    await conn.sendMessage(m.chat, {
        text: CONFIG.responseMessage,
        mentions: [m.sender]
    }, { quoted: m });
};

handler.customPrefix = new RegExp(`^(${CONFIG.prefixes.join("|")})$`, "i");
handler.command = new RegExp();

module.exports = handler;
