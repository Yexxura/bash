(async () => {
    require("./config");
    const {
        default: makeWASocket,
        useMultiFileAuthState,
        makeInMemoryStore,
        makeCacheableSignalKeyStore,
        DisconnectReason,
        fetchLatestBaileysVersion,
        jidNormalizedUser
    } = require("baileys");
    const WebSocket = require("ws");
    const path = require("path");
    const pino = require("pino");
    const { Boom } = require("@hapi/boom");
    const fs = require("fs");
    const CFonts = require('cfonts');
    const chokidar = require("chokidar");
    const readline = require("readline");
    const NodeCache = require("node-cache");
    const yargs = require("yargs/yargs");
    const cp = require("child_process");
    const { promisify } = require("util");
    const exec = promisify(cp.exec).bind(cp);
    const _ = require("lodash");
    const syntaxerror = require("syntax-error");
    const os = require("os");
    const simple = require("./lib/simple.js");
    const { randomBytes } = require("crypto");
    const moment = require("moment-timezone");
    const chalk = require("chalk");
    const readdir = promisify(fs.readdir);
    const stat = promisify(fs.stat);

    // Setup logger dengan warna otomatis
    const logger = pino({
        level: "debug",
        transport: {
            target: "pino-pretty",
            options: {
                colorize: true,
                translateTime: "HH:MM:ss.l",
                ignore: "pid,hostname",
            },
        },
    });

    global.logger = logger;

    function createFolderIfNotExists(folderPath) {
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
            logger.info(`Created folder: ${folderPath}`);
        }
    }

    function createRequiredFolders() {
        const tmpFolderPath = path.join(__dirname, "tmp");
        createFolderIfNotExists(tmpFolderPath);
        const databaseFolderPath = path.join(__dirname, "database");
        createFolderIfNotExists(databaseFolderPath);
    }

    createRequiredFolders();

    const randomID = (length) =>
        randomBytes(Math.ceil(length * 0.5))
            .toString("hex")
            .slice(0, length);

    global.opts = new Object(
        yargs(process.argv.slice(2)).exitProcess(false).parse()
    );

    global.prefix = new RegExp(
        "^[" +
        (
            opts["prefix"] ||
            "/!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.-"
        ).replace(/[|\\{}()[\]^$+*?.\-\^]/g, "\\$&") +
        "]"
    );

    async function load(module) {
        var module_ = await import(`${module}?id=${Date.now()}`);
        var result = module_ && 'default' in module_ ? module_.default : module_;
        return result;
    }

    const dbFilePath = path.join(__dirname, './database/database.json');
    const defaultDatabase = {
        users: {},
        chats: {},
        stats: {},
        msgs: {},
        sticker: {},
        settings: {},
        respon: {},
    };

    global.db = {
        READ: false,
        data: null,
        async read() {
            try {
                const data = fs.readFileSync(dbFilePath, 'utf-8');
                this.data = JSON.parse(data);
                return this.data;
            } catch (error) {
                logger.error('Error reading database file:', error.message);
                this.data = null;
                return null;
            }
        },
        async write(data) {
            try {
                fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2));
                return true;
            } catch (error) {
                logger.error('Error writing database file:', error.message);
                return false;
            }
        }
    };

    global.loadDatabase = async () => {
        if (!db.READ) {
            setInterval(async () => {
                if (db.data) await db.write(db.data);
            }, 2000);
            db.READ = true;
        }
        if (db.data !== null) return;
        await db.read();
        if (db.data === null) {
            logger.warn('Initializing database with default values.');
            db.data = defaultDatabase;
        }
        db.READ = false;
        db.data = {
            ...defaultDatabase,
            ...(db.data || {}),
        };
        db.chain = _.chain(db.data);
    };

    await loadDatabase();

    global.store = makeInMemoryStore({
        logger: pino({ level: "silent" }).child({ stream: "store" }),
    });

    global.authFolder = `session`;

    const { state, saveState, saveCreds } = await useMultiFileAuthState(authFolder);

    const msgRetryCounterCache = new NodeCache();

    const { version } = await fetchLatestBaileysVersion();

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });

    const question = (texto) => new Promise((resolver) => rl.question(texto, resolver));

    store.readFromFile(path.join(process.cwd(), `${authFolder}/store.json`));

    const connectionOptions = {
        printQRInTerminal: false,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (message) => {
            const requiresPatch = !!(
                message.buttonsMessage ||
                message.templateMessage ||
                message.listMessage
            );
            if (requiresPatch) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...message,
                        },
                    },
                };
            }
            return message;
        },
        version,
        browser: ["Ubuntu", "Safari", "20.0.04"],
        logger: pino({ level: "fatal" }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(
                state.keys,
                pino().child({
                    level: "silent",
                    stream: "store",
                })
            ),
        },
        getMessage: async (key) => {
            if (store) {
                const msg = await store.loadMessage(key.remoteJid, key.id);
                return msg?.message || undefined;
            }
            return {
                conversation: "Denji",
            };
        },
        msgRetryCounterCache,
        defaultQueryTimeoutMs: undefined,
    };

    global.conn = simple.makeWASocket(connectionOptions);
    store.bind(conn.ev);

    const isPairing = !conn.authState?.creds?.registered;
    if (isPairing) {
        CFonts.say('WELCOME', {
            font: 'block',
            align: 'center',
            colors: ['greenBright']
        });
        logger.warn("Please enter your WhatsApp number for pairing.");
        console.log(chalk.white.bold(`Operating System Information:
- Platform: ${os.platform()}
- Release: ${os.release()}
- Architecture: ${os.arch()}
- Hostname: ${os.hostname()}
- Total Memory: ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB
- Free Memory: ${(os.freemem() / 1024 / 1024).toFixed(2)} MB
- Uptime: ${os.uptime()} seconds`));
        console.log(chalk.red.bold("[ ! ]") + chalk.cyan.bold(` Please enter your WhatsApp number, for example +628xxxx`));
        const phoneNumber = await question(chalk.green.bold("Your Number : "));
        const code = await conn.requestPairingCode(phoneNumber);
        logger.info(`Your Pairing Code: ${code}`);
    }

    async function connectionUpdate(update) {
        const {
            connection,
            lastDisconnect,
            isNewLogin
        } = update;
        global.stopped = connection;
        if (isNewLogin) conn.isInit = true;
        if (connection === "open") {
            logger.info(`Connected to WhatsApp: ${JSON.stringify(conn.user, null, 2)}`);
        }
        if (connection === "close") {
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
            switch (reason) {
                case DisconnectReason.badSession:
                    logger.fatal(`Bad Session! Delete ${global.authFolder} and reconnect`);
                    await reloadHandler(true);
                    break;
                case DisconnectReason.connectionClosed:
                    logger.warn(`Connection closed, reconnecting...`);
                    await reloadHandler(true);
                    break;
                case DisconnectReason.connectionLost:
                    logger.warn(`Connection lost, reconnecting...`);
                    await reloadHandler(true);
                    break;
                case DisconnectReason.connectionReplaced:
                    logger.fatal(`Connection replaced`);
                    await reloadHandler(true);
                    break;
                case DisconnectReason.loggedOut:
                    logger.fatal(`Logged out, please delete & recreate your session`);
                    await reloadHandler(true);
                    break;
                case DisconnectReason.restartRequired:
                    logger.info(`Restart required, please wait...`);
                    await reloadHandler(true);
                    break;
                case DisconnectReason.timedOut:
                    logger.warn(`Connection timed out, reconnecting...`);
                    await reloadHandler(true);
                    break;
                default:
                    logger.warn(`Connection closed: ${reason || ""} - ${connection || ""}`);
                    await reloadHandler(true);
            }
        }
    }

    process.on("uncaughtException", (err) => {
        logger.error('Uncaught Exception:', err.message);
    });

    let isInit = true;
    let handler = require("./handler");

    global.reloadHandler = async function (restartConn) {
        try {
            const Handler = require("./handler");
            if (Object.keys(Handler || {}).length) handler = Handler;
            if (restartConn) {
                try {
                    conn.ws.close();
                } catch (e) {
                    logger.error("Error closing connection:", e.message);
                }
                conn = {
                    ...conn,
                    ...simple.makeWASocket(connectionOptions),
                };
            }
            if (!isInit) {
                conn.ev.off("messages.upsert", conn.handler);
                conn.ev.off("group-participants.update", conn.onParticipantsUpdate);
                conn.ev.off("connection.update", conn.connectionUpdate);
                conn.ev.off("creds.update", conn.credsUpdate);
            }

            conn.welcome = "Welcome to *@subject* @user\nSemoga betah Dan jangan lupa baca deskripsi\n@desc";
            conn.bye = "Goodbye @user,\nSemoga tenang di alam sana.";
            conn.spromote = "@user telah naik jabatan";
            conn.sdemote = "@user telah turun jabatan🗿";

            conn.handler = handler.handler.bind(conn);
            conn.onParticipantsUpdate = handler.participantsUpdate.bind(conn);
            conn.connectionUpdate = connectionUpdate.bind(conn);
            conn.credsUpdate = saveCreds.bind(conn);

            conn.ev.on("messages.upsert", conn.handler);
            conn.ev.on("group-participants.update", conn.onParticipantsUpdate);
            conn.ev.on("connection.update", conn.connectionUpdate);
            conn.ev.on("creds.update", conn.credsUpdate);

            conn.ev.on('groups.update', updates => {
                for (const update of updates) {
                    const id = update.id;
                    if (store.groupMetadata[id]) {
                        store.groupMetadata[id] = { ...(store.groupMetadata[id] || {}), ...(update || {}) };
                    }
                }
            });

            isInit = false;
            return true;
        } catch (e) {
            logger.error("Error in reloadHandler:", e.message);
            return false;
        }
    };

    global.plugins = {};

    let Scandir = async (dir) => {
        let subdirs = await readdir(dir);
        let files = await Promise.all(subdirs.map(async (subdir) => {
            let res = path.resolve(dir, subdir);
            return (await stat(res)).isDirectory() ? Scandir(res) : res;
        }));
        return files.reduce((a, f) => a.concat(f), []);
    };

    try {
        let files = await Scandir("./plugins");
        let plugins = {};
        for (let filename of files.map(a => a.replace(process.cwd(), ""))) {
            try {
                plugins[filename] = require(path.join(process.cwd(), filename));
            } catch (e) {
                logger.error(`Error loading plugin ${filename}:`, e.message);
                delete plugins[filename];
            }
        }

        const watcher = chokidar.watch(path.resolve("./plugins"), {
            persistent: true,
            ignoreInitial: true
        });

        watcher
            .on('add', async (filename) => {
                logger.info({ type: 'plugin:new' }, `Detected New Plugin: ${filename.replace(process.cwd(), "")}`);
                try {
                    plugins[filename.replace(process.cwd(), "")] = require(filename);
                } catch (e) {
                    logger.error(`Error loading new plugin ${filename}:`, e.message);
                }
            })
            .on('change', async (filename) => {
                try {
                    delete require.cache[filename];
                    let err = syntaxerror(fs.readFileSync(filename), filename.replace(process.cwd(), ""));
                    if (err) {
                        logger.error(`Syntax error in '${filename}':\n${err}`);
                    } else {
                        plugins[filename.replace(process.cwd(), "")] = require(filename);
                        logger.info({ type: 'plugin:update' }, `Updated plugin: ${filename.replace(process.cwd(), "")}`);
                    }
                } catch (e) {
                    logger.error(`Error updating plugin ${filename}:`, e.message);
                }
            })
            .on('unlink', (filename) => {
                logger.warn({ type: 'plugin:delete' }, `Removed plugin: ${filename.replace(process.cwd(), "")}`);
                delete plugins[filename.replace(process.cwd(), "")];
            });

        plugins = Object.fromEntries(Object.entries(plugins).sort(([a], [b]) => a.localeCompare(b)));
        global.plugins = plugins;
        logger.info(`Loaded ${Object.keys(plugins).length} plugins`);
    } catch (e) {
        logger.error("Error loading plugins:", e.message);
    }

    setInterval(async () => {
        try {
            store.writeToFile(path.join(process.cwd(), `${global.authFolder}/store.json`));
        } catch (e) {
            logger.error("Error saving store data:", e.message);
        }
    }, 10 * 1000);

    await reloadHandler();

    global.pickRandom = function (list) {
        return list[Math.floor(Math.random() * list.length)];
    };
})();