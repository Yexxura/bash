const moment = require("moment-timezone");
const fs = require("fs");
const file = require.resolve(__filename);

global.owner = ["6285646584823"];
global.nameowner = "Denji";
global.nomorown = "6285646584823";

global.namebot = "Den Botto";
global.version = "1.0.0";
global.author = `Time: ${moment().tz("Asia/Jakarta").format("HH.mm")} WIB`;

global.fetch = require("node-fetch");
global.axios = require("axios");

global.Func = new (require(process.cwd() + "/lib/func"))();

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log("config.js updated");
  delete require.cache[file];
  require(file);
});
