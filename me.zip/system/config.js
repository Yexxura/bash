/*
┏━━━━━━━━━━━━━━━┓  
┃ RIKZZ BASE - WHATSAPP     
┣━━━━━━━━━━━━━━━┛
┃♕ Creator: kayzen           
┃♕ AI Helper: ChatGPT             
┃♔ Version: 1.0.0                   
┗━━━━━━━━━━━━━━━┛
*/
//========RIKZZ========
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["14314009636", "6281532929498"] 
global.namabot = 'Asur4'
//======================
global.mess = { 
owner: 'owner only!',
premium: 'anda bukan user premium',
succes: 'succes'
}
//======================